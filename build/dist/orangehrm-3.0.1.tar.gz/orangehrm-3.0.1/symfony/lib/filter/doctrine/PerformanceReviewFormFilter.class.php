<?php

/**
 * PerformanceReview filter form.
 *
 * @package    filters
 * @subpackage PerformanceReview *
 * @version    SVN: $Id: sfDoctrineFormFilterTemplate.php 11675 2008-09-19 15:21:38Z fabien $
 */
class PerformanceReviewFormFilter extends BasePerformanceReviewFormFilter
{
  public function configure()
  {
  }
}