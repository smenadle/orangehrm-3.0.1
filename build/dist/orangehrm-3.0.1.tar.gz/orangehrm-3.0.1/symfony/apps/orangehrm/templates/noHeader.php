<?php require_once '_header.php'; ?>

    </head>
    <body>
      
        <div id="wrapper">
            
            <div id="content">

                  <?php echo $sf_content ?>

            </div> <!-- content -->
          
        </div> <!-- wrapper -->
        
<?php require_once '_footer.php'; ?>