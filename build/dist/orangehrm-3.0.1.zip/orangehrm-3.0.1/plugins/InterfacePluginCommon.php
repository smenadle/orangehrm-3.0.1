<?php

interface InterfacePluginCommon {
	public function  routePlugin ($request);
}

?>