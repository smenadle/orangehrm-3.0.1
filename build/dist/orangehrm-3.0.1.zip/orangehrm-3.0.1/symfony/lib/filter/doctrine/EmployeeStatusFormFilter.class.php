<?php

/**
 * EmployeeStatus filter form.
 *
 * @package    filters
 * @subpackage EmployeeStatus *
 * @version    SVN: $Id: sfDoctrineFormFilterTemplate.php 11675 2008-09-19 15:21:38Z fabien $
 */
class EmployeeStatusFormFilter extends BaseEmployeeStatusFormFilter
{
  public function configure()
  {
  }
}